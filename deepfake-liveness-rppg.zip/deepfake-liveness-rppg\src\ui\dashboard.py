﻿"""
HUD & Oscilloscope Dashboard for Real-Time rPPG Liveness Verification.
Draws:
1. Face landmarks & multi-region ROI masks
2. Real-time dynamic pulse oscilloscope graph
3. Vital signs (BPM, SNR, Spatial Sync)
4. Liveness Badge (GENUINE HUMAN vs SUSPECTED DEEPFAKE)
5. Interactive sensitivity indicator
"""

import cv2
import numpy as np
from typing import Optional, Dict
from src.core.face_tracker import FaceTrackingResult
from src.core.liveness_verifier import LivenessVerdict

class Dashboard:
    def __init__(self, width: int = 1000, height: int = 700):
        self.width = width
        self.height = height

    def render(
        self,
        frame_bgr: np.ndarray,
        face_result: Optional[FaceTrackingResult],
        verdict: LivenessVerdict,
        fps: float = 30.0,
        sensitivity: str = "normal"
    ) -> np.ndarray:
        """
        Compose HUD overlays and pulse graph onto the video frame.
        """
        canvas = cv2.resize(frame_bgr, (self.width, self.height))

        # 1. Draw ROIs and Landmarks if face is present
        if face_result is not None:
            self._draw_face_overlays(canvas, face_result)

        # 2. Draw Semi-transparent HUD Header & Metrics Cards
        self._draw_hud_header(canvas, verdict, fps, face_result is not None, sensitivity)

        # 3. Draw Real-Time Pulse Oscilloscope Graph at Bottom
        self._draw_pulse_graph(canvas, verdict.filtered_pulse)

        # 4. Draw Diagnostic Status Footer
        self._draw_footer(canvas, verdict)

        return canvas

    def _draw_face_overlays(self, canvas: np.ndarray, face_result: FaceTrackingResult):
        """Draw bounding box and colored ROI polygons."""
        overlay = canvas.copy()
        cv2.fillConvexPoly(overlay, face_result.roi_polygons["forehead"], (255, 200, 0))   # Cyan/Yellowish
        cv2.fillConvexPoly(overlay, face_result.roi_polygons["left_cheek"], (0, 200, 255)) # Orange
        cv2.fillConvexPoly(overlay, face_result.roi_polygons["right_cheek"], (0, 200, 255))
        
        # Blend overlay (35% opacity)
        cv2.addWeighted(overlay, 0.35, canvas, 0.65, 0, canvas)

        # Draw ROI borders
        cv2.polylines(canvas, [face_result.roi_polygons["forehead"]], True, (255, 220, 0), 2)
        cv2.polylines(canvas, [face_result.roi_polygons["left_cheek"]], True, (0, 220, 255), 2)
        cv2.polylines(canvas, [face_result.roi_polygons["right_cheek"]], True, (0, 220, 255), 2)

    def _draw_hud_header(self, canvas: np.ndarray, verdict: LivenessVerdict, fps: float, has_face: bool, sensitivity: str):
        """Draw top metrics panel and liveness verdict badge."""
        overlay = canvas.copy()
        cv2.rectangle(overlay, (0, 0), (self.width, 105), (15, 18, 24), -1)
        cv2.addWeighted(overlay, 0.85, canvas, 0.15, 0, canvas)
        cv2.line(canvas, (0, 105), (self.width, 105), (60, 70, 85), 1)

        # Left: App title & FPS
        cv2.putText(canvas, "BIO-VERIFY // rPPG LIVENESS ENGINE", (20, 28),
                    cv2.FONT_HERSHEY_DUPLEX, 0.62, (220, 220, 230), 1, cv2.LINE_AA)
        cv2.putText(canvas, f"FPS: {fps:.1f} | MODE: {sensitivity.upper()} ('c' to toggle)", (20, 48),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (140, 150, 160), 1, cv2.LINE_AA)

        # Progress bar during initial calibration
        if verdict.buffer_progress < 1.0:
            bar_w = 260
            filled = int(bar_w * verdict.buffer_progress)
            cv2.rectangle(canvas, (20, 68), (20 + bar_w, 82), (40, 45, 55), -1)
            cv2.rectangle(canvas, (20, 68), (20 + filled, 82), (0, 180, 240), -1)
            cv2.putText(canvas, f"CALIBRATING: {int(verdict.buffer_progress * 100)}% (Hold still)", (20, 96),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.40, (0, 180, 240), 1, cv2.LINE_AA)
        else:
            cv2.putText(canvas, "BUFFER: LOCKED (Ready)", (20, 78),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.45, (80, 220, 120), 1, cv2.LINE_AA)

        # Center: Telemetry cards (BPM, SNR, Spatial Sync)
        start_x = 370
        # Card 1: Heart Rate
        bpm_str = f"{verdict.bpm:.1f} BPM" if verdict.bpm > 0 else "-- BPM"
        cv2.putText(canvas, "PULSE RATE", (start_x, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (140, 150, 160), 1, cv2.LINE_AA)
        cv2.putText(canvas, bpm_str, (start_x, 60), cv2.FONT_HERSHEY_DUPLEX, 0.75, (255, 120, 80), 2, cv2.LINE_AA)

        # Card 2: SNR
        snr_str = f"{verdict.snr_db:+.1f} dB" if verdict.bpm > 0 else "-- dB"
        snr_color = (80, 220, 120) if verdict.snr_db >= 1.2 else (60, 100, 240)
        cv2.putText(canvas, "CARDIAC SNR", (start_x + 130, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (140, 150, 160), 1, cv2.LINE_AA)
        cv2.putText(canvas, snr_str, (start_x + 130, 60), cv2.FONT_HERSHEY_DUPLEX, 0.70, snr_color, 2, cv2.LINE_AA)

        # Card 3: Regional Sync
        sync_str = f"r={verdict.spatial_correlation:.2f}" if verdict.bpm > 0 else "r=--"
        sync_color = (80, 220, 120) if verdict.spatial_correlation >= 0.32 else (60, 100, 240)
        cv2.putText(canvas, "SPATIAL SYNC", (start_x + 250, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.40, (140, 150, 160), 1, cv2.LINE_AA)
        cv2.putText(canvas, sync_str, (start_x + 250, 60), cv2.FONT_HERSHEY_DUPLEX, 0.70, sync_color, 2, cv2.LINE_AA)

        # Right: Liveness Verdict Badge
        badge_w, badge_h = 220, 65
        bx = self.width - badge_w - 20
        by = 20

        if not has_face:
            bg_color = (50, 50, 60)
            text_1 = "NO SUBJECT"
            text_2 = "Face Not Detected"
            txt_color = (180, 180, 180)
        elif verdict.status_label == "ANALYZING":
            bg_color = (160, 110, 0)
            text_1 = "CALIBRATING..."
            text_2 = "Scanning Blood Flow"
            txt_color = (255, 255, 255)
        elif verdict.status_label == "GENUINE_HUMAN":
            bg_color = (30, 140, 45)   # Green
            text_1 = "GENUINE HUMAN"
            text_2 = f"Confidence: {verdict.liveness_score:.0f}%"
            txt_color = (255, 255, 255)
        else:
            bg_color = (30, 30, 190)   # Red
            text_1 = "SUSPECTED DEEPFAKE"
            text_2 = "Spoof / Incoherent Pulse"
            txt_color = (255, 255, 255)

        cv2.rectangle(canvas, (bx, by), (bx + badge_w, by + badge_h), bg_color, -1)
        cv2.rectangle(canvas, (bx, by), (bx + badge_w, by + badge_h), (255, 255, 255), 1)
        cv2.putText(canvas, text_1, (bx + 12, by + 28), cv2.FONT_HERSHEY_DUPLEX, 0.58, txt_color, 2, cv2.LINE_AA)
        cv2.putText(canvas, text_2, (bx + 12, by + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.40, txt_color, 1, cv2.LINE_AA)

    def _draw_pulse_graph(self, canvas: np.ndarray, pulse: np.ndarray):
        """Draw an oscilloscope-style real-time cardiac waveform graph."""
        graph_x, graph_y = 20, self.height - 130
        graph_w, graph_h = self.width - 40, 80

        overlay = canvas.copy()
        cv2.rectangle(overlay, (graph_x, graph_y), (graph_x + graph_w, graph_y + graph_h), (15, 18, 24), -1)
        cv2.addWeighted(overlay, 0.75, canvas, 0.25, 0, canvas)
        cv2.rectangle(canvas, (graph_x, graph_y), (graph_x + graph_w, graph_y + graph_h), (50, 60, 75), 1)

        cv2.putText(canvas, "BLOOD VOLUME PULSE (BVP) WAVEFORM", (graph_x + 10, graph_y + 18),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.40, (140, 150, 160), 1, cv2.LINE_AA)

        mid_y = graph_y + graph_h // 2 + 8
        cv2.line(canvas, (graph_x, mid_y), (graph_x + graph_w, mid_y), (35, 42, 52), 1)

        if pulse is None or len(pulse) < 5:
            return

        max_abs = np.max(np.abs(pulse))
        if max_abs < 1e-6:
            max_abs = 1.0

        pts = []
        n_pts = len(pulse)
        for i in range(n_pts):
            px = int(graph_x + (i / (n_pts - 1)) * graph_w)
            norm_val = pulse[i] / max_abs
            py = int(mid_y - norm_val * (graph_h // 2 - 16))
            py = max(graph_y + 20, min(graph_y + graph_h - 5, py))
            pts.append((px, py))

        for i in range(1, len(pts)):
            cv2.line(canvas, pts[i - 1], pts[i], (0, 240, 160), 2, cv2.LINE_AA)

    def _draw_footer(self, canvas: np.ndarray, verdict: LivenessVerdict):
        """Draw bottom diagnostic string with reason / diagnosis."""
        fy = self.height - 18
        # Truncate reason if too long to prevent wrapping
        text = f"STATUS: {verdict.reason}"
        if len(text) > 110:
            text = text[:107] + "..."
        cv2.putText(canvas, text, (25, fy),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.40, (180, 190, 205), 1, cv2.LINE_AA)
