﻿"""
rPPG Pulse Signal Extraction Engine.
Implements:
1. Green-Channel Extraction (Verkruysse et al.)
2. CHROM: Chrominance-based method (de Haan & Jeanne)
3. POS: Plane-Orthogonal-to-Skin method (Wang et al.)
"""

import numpy as np
from typing import Optional

class RPPGExtractor:
    def __init__(self, method: str = "pos", buffer_size: int = 150):
        """
        method: 'pos', 'chrom', or 'green'
        buffer_size: Number of frames in rolling buffer (e.g. 150 frames ~ 5 sec at 30fps)
        """
        self.method = method.lower()
        self.buffer_size = buffer_size

    def extract(self, rgb_buffer: np.ndarray) -> np.ndarray:
        """
        Extract blood volume pulse (BVP) from a sequence of RGB observations.
        rgb_buffer: shape (N, 3) where columns are R, G, B channels.
        Returns: 1D numpy array of length N containing the raw pulse signal.
        """
        if len(rgb_buffer) < 10:
            return np.zeros(len(rgb_buffer))

        if self.method == "green":
            return self._extract_green(rgb_buffer)
        elif self.method == "chrom":
            return self._extract_chrom(rgb_buffer)
        elif self.method == "pos":
            return self._extract_pos(rgb_buffer)
        else:
            return self._extract_pos(rgb_buffer)

    def _extract_green(self, rgb: np.ndarray) -> np.ndarray:
        """Normalized green channel pulse."""
        g = rgb[:, 1]
        mean_g = np.mean(g)
        if mean_g < 1e-6:
            return np.zeros_like(g)
        return -(g / mean_g - 1.0)  # Inverted so systolic peak is positive

    def _extract_chrom(self, rgb: np.ndarray) -> np.ndarray:
        """
        Chrominance-based rPPG method.
        Projects normalized RGB onto chrominance planes to cancel specular noise.
        """
        # Normalize each channel by its temporal mean
        means = np.mean(rgb, axis=0)
        means[means < 1e-6] = 1e-6
        norm_rgb = rgb / means

        R = norm_rgb[:, 0]
        G = norm_rgb[:, 1]
        B = norm_rgb[:, 2]

        # Chrominance signals
        Xs = 3.0 * R - 2.0 * G
        Ys = 1.5 * R + G - 1.5 * B

        std_x = np.std(Xs)
        std_y = np.std(Ys)
        
        if std_y < 1e-6:
            return np.zeros_like(R)

        alpha = std_x / std_y
        pulse = Xs - alpha * Ys
        return -pulse

    def _extract_pos(self, rgb: np.ndarray) -> np.ndarray:
        """
        Plane-Orthogonal-to-Skin (POS) method.
        Robust to skin tone variations and lighting changes.
        """
        means = np.mean(rgb, axis=0)
        means[means < 1e-6] = 1e-6
        norm_rgb = rgb / means

        R = norm_rgb[:, 0]
        G = norm_rgb[:, 1]
        B = norm_rgb[:, 2]

        # Projection onto orthogonal planes
        S1 = G - B
        S2 = G + B - 2.0 * R

        std_s1 = np.std(S1)
        std_s2 = np.std(S2)

        if std_s2 < 1e-6:
            return np.zeros_like(R)

        h = S1 + (std_s1 / std_s2) * S2
        return -h
