﻿"""
Unit Tests for rPPG Pipeline and Liveness Verifier.
Tests synthetic signals, filter response, BPM detection accuracy, and anti-spoofing logic.
"""

import unittest
import numpy as np
import sys
import os

# Add project root to sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.signal_processing import (
    butterworth_bandpass,
    compute_psd,
    extract_bpm,
    compute_snr,
    detrend_signal
)
from src.core.rppg_extractor import RPPGExtractor
from src.core.liveness_verifier import LivenessVerifier

class TestRPPGPipeline(unittest.TestCase):

    def setUp(self):
        self.fs = 30.0  # 30 frames per second
        self.duration = 6.0  # 6 seconds
        self.n_samples = int(self.fs * self.duration)
        self.t = np.linspace(0, self.duration, self.n_samples, endpoint=False)

    def test_bpm_detection_accuracy(self):
        """Verify that a synthetic 75 BPM pulse is accurately detected within +/- 1.5 BPM."""
        target_bpm = 75.0
        target_freq = target_bpm / 60.0  # 1.25 Hz

        # Create pure pulse + mild 2nd harmonic + baseline wander + small noise
        pulse = np.sin(2 * np.pi * target_freq * self.t)
        harmonic = 0.25 * np.sin(2 * np.pi * (2 * target_freq) * self.t)
        baseline_drift = 0.5 * np.sin(2 * np.pi * 0.1 * self.t)
        noise = 0.1 * np.random.normal(size=self.n_samples)

        raw_signal = pulse + harmonic + baseline_drift + noise

        # Process signal
        filtered = butterworth_bandpass(raw_signal, fs=self.fs)
        freqs, psd = compute_psd(filtered, fs=self.fs)
        est_bpm, peak_freq = extract_bpm(freqs, psd)

        self.assertAlmostEqual(est_bpm, target_bpm, delta=2.0)
        
        # Verify SNR is strongly positive (> 5 dB)
        snr = compute_snr(freqs, psd, peak_freq)
        self.assertGreater(snr, 4.0)

    def test_noise_rejection_deepfake_simulation(self):
        """Verify that random pixel noise (simulating poor deepfake) produces low SNR and fails liveness."""
        np.random.seed(42)
        pure_noise = np.random.normal(0, 1.0, self.n_samples)

        filtered = butterworth_bandpass(pure_noise, fs=self.fs)
        freqs, psd = compute_psd(filtered, fs=self.fs)
        est_bpm, peak_freq = extract_bpm(freqs, psd)
        snr = compute_snr(freqs, psd, peak_freq)

        # White noise should not have a concentrated harmonic peak
        self.assertLess(snr, 2.5)

    def test_multi_region_correlation_genuine(self):
        """Verify that synchronous pulses across forehead and cheeks yield high correlation and pass liveness."""
        target_freq = 1.2  # 72 BPM
        clean_pulse = np.sin(2 * np.pi * target_freq * self.t)
        
        # Add slight physiological phase/amplitude differences
        forehead = clean_pulse + 0.05 * np.random.normal(size=self.n_samples)
        left_cheek = 0.9 * np.sin(2 * np.pi * target_freq * self.t + 0.05) + 0.05 * np.random.normal(size=self.n_samples)
        right_cheek = 0.95 * np.sin(2 * np.pi * target_freq * self.t + 0.02) + 0.05 * np.random.normal(size=self.n_samples)
        combined = (forehead + left_cheek + right_cheek) / 3.0

        verifier = LivenessVerifier(fs=self.fs, min_frames=90, buffer_size=150)
        verdict = verifier.verify(combined, forehead, left_cheek, right_cheek)

        self.assertTrue(verdict.is_live)
        self.assertEqual(verdict.status_label, "GENUINE_HUMAN")
        self.assertGreater(verdict.spatial_correlation, 0.85)
        self.assertGreaterEqual(verdict.liveness_score, 70.0)

    def test_multi_region_decorrelation_spoof(self):
        """Verify that decorrelated regions (face swap deepfake artifact) are caught as spoof."""
        # Forehead has one frequency, cheeks have completely independent noise/signals
        forehead = np.sin(2 * np.pi * 1.2 * self.t)
        left_cheek = np.random.normal(size=self.n_samples)
        right_cheek = np.sin(2 * np.pi * 2.1 * self.t)
        combined = (forehead + left_cheek + right_cheek) / 3.0

        verifier = LivenessVerifier(fs=self.fs, min_frames=90, buffer_size=150)
        verdict = verifier.verify(combined, forehead, left_cheek, right_cheek)

        self.assertFalse(verdict.is_live)
        self.assertEqual(verdict.status_label, "SUSPECTED_DEEPFAKE")

    def test_rppg_extractors(self):
        """Verify POS, CHROM, and Green channel extractors return valid non-empty arrays."""
        rgb_data = np.ones((self.n_samples, 3)) * 128.0
        # Add subtle green pulse modulation
        rgb_data[:, 1] += 2.0 * np.sin(2 * np.pi * 1.2 * self.t)

        for method in ["pos", "chrom", "green"]:
            extractor = RPPGExtractor(method=method)
            pulse = extractor.extract(rgb_data)
            self.assertEqual(len(pulse), self.n_samples)
            self.assertFalse(np.all(pulse == 0))

if __name__ == "__main__":
    unittest.main()
