﻿"""
End-to-End Headless Pipeline Test.
Verifies the complete integration:
FaceTracker -> RPPGExtractor -> LivenessVerifier -> Dashboard Renderer.
"""

import unittest
import numpy as np
import cv2
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.rppg_extractor import RPPGExtractor
from src.core.liveness_verifier import LivenessVerifier
from src.ui.dashboard import Dashboard

class TestEndToEndPipeline(unittest.TestCase):

    def test_full_pipeline_genuine_human(self):
        """Simulate 150 frames of a real human with synchronous cardiac pulse at 72 BPM."""
        fs = 30.0
        n_frames = 150
        extractor = RPPGExtractor(method="pos", buffer_size=150)
        verifier = LivenessVerifier(fs=fs, min_frames=90, buffer_size=150)
        dashboard = Dashboard(width=1000, height=700)

        buf_comb, buf_fh, buf_lc, buf_rc = [], [], [], []

        for i in range(n_frames):
            t = i / fs
            # 72 BPM = 1.2 Hz pulse
            cardiac_wave = 2.0 * np.sin(2 * np.pi * 1.2 * t)
            
            # Baseline RGB + subtle blood volume pulsation
            fh = np.array([125.0, 135.0 + cardiac_wave, 115.0])
            lc = np.array([124.0, 134.0 + cardiac_wave * 0.96, 114.0])
            rc = np.array([126.0, 136.0 + cardiac_wave * 0.98, 116.0])
            comb = (fh + lc + rc) / 3.0

            buf_comb.append(comb)
            buf_fh.append(fh)
            buf_lc.append(lc)
            buf_rc.append(rc)

        p_comb = extractor.extract(np.array(buf_comb))
        p_fh = extractor.extract(np.array(buf_fh))
        p_lc = extractor.extract(np.array(buf_lc))
        p_rc = extractor.extract(np.array(buf_rc))

        verdict = verifier.verify(p_comb, p_fh, p_lc, p_rc)

        # Assert Genuine Human is correctly classified
        self.assertTrue(verdict.is_live)
        self.assertEqual(verdict.status_label, "GENUINE_HUMAN")
        self.assertAlmostEqual(verdict.bpm, 72.0, delta=2.0)
        self.assertGreater(verdict.snr_db, 3.0)
        self.assertGreater(verdict.spatial_correlation, 0.85)

        # Assert Dashboard rendering succeeds
        dummy_frame = np.zeros((480, 640, 3), dtype=np.uint8)
        rendered = dashboard.render(dummy_frame, None, verdict, fps=30.0)
        self.assertEqual(rendered.shape, (700, 1000, 3))

    def test_full_pipeline_deepfake_noise(self):
        """Simulate 150 frames of an AI deepfake with uncorrelated facial regions."""
        fs = 30.0
        n_frames = 150
        extractor = RPPGExtractor(method="pos", buffer_size=150)
        verifier = LivenessVerifier(fs=fs, min_frames=90, buffer_size=150)

        buf_comb, buf_fh, buf_lc, buf_rc = [], [], [], []

        np.random.seed(123)
        for i in range(n_frames):
            # Uncorrelated random signals across regions
            fh = np.array([125.0, 135.0 + np.random.normal(0, 1.5), 115.0])
            lc = np.array([124.0, 134.0 + np.random.normal(0, 1.5), 114.0])
            rc = np.array([126.0, 136.0 + np.random.normal(0, 1.5), 116.0])
            comb = (fh + lc + rc) / 3.0

            buf_comb.append(comb)
            buf_fh.append(fh)
            buf_lc.append(lc)
            buf_rc.append(rc)

        p_comb = extractor.extract(np.array(buf_comb))
        p_fh = extractor.extract(np.array(buf_fh))
        p_lc = extractor.extract(np.array(buf_lc))
        p_rc = extractor.extract(np.array(buf_rc))

        verdict = verifier.verify(p_comb, p_fh, p_lc, p_rc)

        # Assert Deepfake is caught
        self.assertFalse(verdict.is_live)
        self.assertEqual(verdict.status_label, "SUSPECTED_DEEPFAKE")

if __name__ == "__main__":
    unittest.main()
