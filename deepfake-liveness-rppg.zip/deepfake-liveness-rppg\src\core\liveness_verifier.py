﻿"""
Physiological Liveness & Anti-Spoofing Verification Engine.
Validates biological presence by assessing:
1. Signal-to-Noise Ratio (SNR) of cardiac pulse
2. Spatial cross-correlation across forehead and cheeks (with shadow tolerance)
3. Dynamic frame rate calibration (fs)
4. Configurable sensitivity levels (relaxed, normal, strict)
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, Tuple, Optional
from .signal_processing import (
    butterworth_bandpass,
    compute_psd,
    extract_bpm,
    compute_snr
)

@dataclass
class LivenessVerdict:
    is_live: bool
    liveness_score: float         # 0.0 to 100.0%
    bpm: float                    # Estimated Heart Rate
    snr_db: float                 # Signal-to-Noise Ratio in dB
    spatial_correlation: float    # Effective spatial synchronization
    regional_correlations: Dict[str, float]
    status_label: str             # "GENUINE_HUMAN", "SUSPECTED_DEEPFAKE", "ANALYZING", "NO_FACE"
    reason: str                   # Diagnostic guidance
    filtered_pulse: np.ndarray    # Waveform for visualization
    buffer_progress: float        # 0.0 to 1.0

class LivenessVerifier:
    def __init__(
        self,
        fs: float = 30.0,
        min_frames: int = 75,     # ~2.5 to 3 seconds minimum to start analysis
        buffer_size: int = 150,   # ~5 seconds full window
        sensitivity: str = "normal",
        min_bpm: float = 45.0,
        max_bpm: float = 150.0
    ):
        self.default_fs = fs
        self.min_frames = min_frames
        self.buffer_size = buffer_size
        self.min_bpm = min_bpm
        self.max_bpm = max_bpm
        self.set_sensitivity(sensitivity)

    def set_sensitivity(self, mode: str):
        """Set detection sensitivity: 'relaxed', 'normal', or 'strict'."""
        mode = mode.lower()
        if mode == "relaxed":
            self.snr_threshold = 0.7    # Tolerates dim lighting / budget webcams
            self.corr_threshold = 0.25
            self.pass_score = 45.0
            self.sensitivity = "relaxed"
        elif mode == "strict":
            self.snr_threshold = 2.2    # Studio lighting / high security KYC
            self.corr_threshold = 0.50
            self.pass_score = 65.0
            self.sensitivity = "strict"
        else:  # normal
            self.snr_threshold = 1.2    # Standard consumer webcam in normal room
            self.corr_threshold = 0.32
            self.pass_score = 52.0
            self.sensitivity = "normal"

    def verify(
        self,
        combined_pulse: np.ndarray,
        forehead_pulse: np.ndarray,
        left_cheek_pulse: np.ndarray,
        right_cheek_pulse: np.ndarray,
        fs: Optional[float] = None
    ) -> LivenessVerdict:
        """
        Evaluate multi-channel pulses with dynamic sampling rate adaptation.
        """
        actual_fs = fs if (fs is not None and fs > 5.0) else self.default_fs
        n_samples = len(combined_pulse)
        progress = min(1.0, n_samples / self.buffer_size)

        if n_samples < self.min_frames:
            return LivenessVerdict(
                is_live=False,
                liveness_score=0.0,
                bpm=0.0,
                snr_db=-10.0,
                spatial_correlation=0.0,
                regional_correlations={"FL": 0.0, "FR": 0.0, "LR": 0.0},
                status_label="ANALYZING",
                reason=f"Calibrating micro-vascular buffer ({n_samples}/{self.min_frames} frames @ {actual_fs:.1f} FPS)...",
                filtered_pulse=np.zeros(max(1, n_samples)),
                buffer_progress=progress
            )

        # Step 1: Bandpass filter all 3 regions + combined pulse using dynamic actual_fs
        filt_comb = butterworth_bandpass(combined_pulse, fs=actual_fs)
        filt_fh = butterworth_bandpass(forehead_pulse, fs=actual_fs)
        filt_lc = butterworth_bandpass(left_cheek_pulse, fs=actual_fs)
        filt_rc = butterworth_bandpass(right_cheek_pulse, fs=actual_fs)

        # Step 2: Compute Power Spectral Density & Heart Rate
        freqs, psd = compute_psd(filt_comb, fs=actual_fs)
        bpm, peak_freq = extract_bpm(freqs, psd, min_bpm=self.min_bpm, max_bpm=self.max_bpm)
        snr = compute_snr(freqs, psd, peak_freq)

        # Step 3: Compute Spatial Multi-Region Correlation with shadow resilience
        r_fl = self._pearson_corr(filt_fh, filt_lc)
        r_fr = self._pearson_corr(filt_fh, filt_rc)
        r_lr = self._pearson_corr(filt_lc, filt_rc)

        # In real rooms, light often comes from one side.
        # If forehead synchronizes with either cheek, that proves genuine blood flow.
        best_forehead_cheek_sync = max(r_fl, r_fr)
        effective_sync = float(np.clip(0.60 * best_forehead_cheek_sync + 0.40 * max(0.0, r_lr), -1.0, 1.0))

        # Step 4: Scoring
        # SNR component: scaled around sensitivity threshold
        snr_norm = float(np.clip((snr - self.snr_threshold + 1.0) / 4.0, 0.0, 1.0))
        # Correlation component:
        corr_norm = float(np.clip((effective_sync - self.corr_threshold + 0.2) / 0.6, 0.0, 1.0))
        
        liveness_score = round(100.0 * (0.50 * snr_norm + 0.50 * corr_norm), 1)

        # Step 5: Liveness Decision Logic
        is_live = False
        status_label = "SUSPECTED_DEEPFAKE"
        reasons = []

        if bpm < self.min_bpm or bpm > self.max_bpm:
            reasons.append(f"Cardiac frequency unclear or out of bounds ({bpm:.1f} BPM)")
        
        if snr < self.snr_threshold:
            reasons.append(f"Low pulse contrast (SNR: {snr:+.1f} dB < {self.snr_threshold:.1f} dB - increase light or hold still)")
            
        if effective_sync < self.corr_threshold:
            reasons.append(f"Regional decorrelation (sync={effective_sync:.2f} < {self.corr_threshold:.2f})")

        if len(reasons) == 0 and liveness_score >= self.pass_score:
            is_live = True
            status_label = "GENUINE_HUMAN"
            reason = f"Verified living human: {bpm:.0f} BPM (SNR: {snr:+.1f} dB, Sync: {effective_sync:.2f})"
        else:
            reason = " | ".join(reasons) if reasons else "Inconsistent physiological signals."

        return LivenessVerdict(
            is_live=is_live,
            liveness_score=liveness_score,
            bpm=bpm,
            snr_db=snr,
            spatial_correlation=effective_sync,
            regional_correlations={"FL": r_fl, "FR": r_fr, "LR": r_lr},
            status_label=status_label,
            reason=reason,
            filtered_pulse=filt_comb,
            buffer_progress=progress
        )

    def _pearson_corr(self, x: np.ndarray, y: np.ndarray) -> float:
        """Compute Pearson correlation coefficient between two signals."""
        std_x = np.std(x)
        std_y = np.std(y)
        if std_x < 1e-6 or std_y < 1e-6:
            return 0.0
        r = np.corrcoef(x, y)[0, 1]
        return float(0.0 if np.isnan(r) else r)
