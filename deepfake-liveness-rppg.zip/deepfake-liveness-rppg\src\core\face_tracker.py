﻿"""
Face Tracker and Multi-ROI Extractor using MediaPipe Tasks FaceLandmarker.
Tracks the face and extracts RGB color signals from 3 distinct facial regions:
- Forehead
- Left Cheek
- Right Cheek
Uses convex hulls to ensure optimal skin pixel sampling.
"""

import os
import urllib.request
import numpy as np
import cv2
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

# Standard model download URL for MediaPipe FaceLandmarker
MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task"
DEFAULT_MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "data", "models", "face_landmarker.task")

# Expanded landmark sets for reliable skin patch coverage
FOREHEAD_LANDMARKS = [10, 151, 9, 8, 109, 67, 103, 104, 69, 108, 338, 297, 332, 333, 299, 337]
LEFT_CHEEK_LANDMARKS = [347, 348, 349, 350, 425, 427, 436, 411, 280, 352, 329, 330]
RIGHT_CHEEK_LANDMARKS = [118, 119, 120, 121, 205, 207, 216, 187, 50, 123, 100, 101]

@dataclass
class FaceTrackingResult:
    landmarks: np.ndarray             # (478, 2) in pixel coordinates
    bbox: Tuple[int, int, int, int]   # (x, y, w, h)
    forehead_rgb: np.ndarray          # Mean [R, G, B]
    left_cheek_rgb: np.ndarray        # Mean [R, G, B]
    right_cheek_rgb: np.ndarray       # Mean [R, G, B]
    combined_rgb: np.ndarray          # Weighted average [R, G, B]
    roi_polygons: Dict[str, np.ndarray]  # Convex hull polygon points for rendering

class FaceTracker:
    def __init__(self, model_path: Optional[str] = None):
        self.model_path = model_path or DEFAULT_MODEL_PATH
        self._ensure_model_exists()
        
        base_options = python.BaseOptions(model_asset_path=self.model_path)
        options = vision.FaceLandmarkerOptions(
            base_options=base_options,
            output_face_blendshapes=False,
            output_facial_transformation_matrixes=False,
            num_faces=1
        )
        self.detector = vision.FaceLandmarker.create_from_options(options)

    def _ensure_model_exists(self):
        os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
        if not os.path.exists(self.model_path):
            print(f"Downloading FaceLandmarker model to {self.model_path}...")
            urllib.request.urlretrieve(MODEL_URL, self.model_path)
            print("Model downloaded successfully!")

    def process_frame(self, frame_bgr: np.ndarray) -> Optional[FaceTrackingResult]:
        """
        Process a single BGR frame, detect face landmarks and extract mean RGB for ROIs.
        """
        h, w = frame_bgr.shape[:2]
        frame_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=frame_rgb)
        
        result = self.detector.detect(mp_image)
        if not result.face_landmarks or len(result.face_landmarks) == 0:
            return None

        # Convert normalized coordinates to pixel coordinates
        landmarks_norm = result.face_landmarks[0]
        landmarks_px = np.array([
            [int(lm.x * w), int(lm.y * h)] for lm in landmarks_norm
        ], dtype=np.int32)

        # Compute overall face bounding box
        x_min, y_min = np.min(landmarks_px, axis=0)
        x_max, y_max = np.max(landmarks_px, axis=0)
        bbox = (max(0, x_min), max(0, y_min), min(w - x_min, x_max - x_min), min(h - y_min, y_max - y_min))

        # Build convex hulls for ROIs to ensure solid pixel coverage
        fh_pts = landmarks_px[FOREHEAD_LANDMARKS]
        lc_pts = landmarks_px[LEFT_CHEEK_LANDMARKS]
        rc_pts = landmarks_px[RIGHT_CHEEK_LANDMARKS]

        fh_poly = cv2.convexHull(fh_pts)
        lc_poly = cv2.convexHull(lc_pts)
        rc_poly = cv2.convexHull(rc_pts)

        roi_polygons = {
            "forehead": fh_poly,
            "left_cheek": lc_poly,
            "right_cheek": rc_poly
        }

        # Extract mean RGB for each ROI
        fh_rgb = self._extract_roi_mean_rgb(frame_rgb, fh_poly, (h, w))
        lc_rgb = self._extract_roi_mean_rgb(frame_rgb, lc_poly, (h, w))
        rc_rgb = self._extract_roi_mean_rgb(frame_rgb, rc_poly, (h, w))

        # Combined weighted average across regions
        combined_rgb = 0.4 * fh_rgb + 0.3 * lc_rgb + 0.3 * rc_rgb

        return FaceTrackingResult(
            landmarks=landmarks_px,
            bbox=bbox,
            forehead_rgb=fh_rgb,
            left_cheek_rgb=lc_rgb,
            right_cheek_rgb=rc_rgb,
            combined_rgb=combined_rgb,
            roi_polygons=roi_polygons
        )

    def _extract_roi_mean_rgb(self, frame_rgb: np.ndarray, polygon: np.ndarray, shape: Tuple[int, int]) -> np.ndarray:
        h, w = shape
        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.fillConvexPoly(mask, polygon, 255)
        
        # Calculate mean of R, G, B within the mask
        mean_val = cv2.mean(frame_rgb, mask=mask)[:3]
        return np.array(mean_val, dtype=np.float64)
