﻿"""
Signal Processing & Spectral Analysis for rPPG Signals.
Implements:
- Zero-phase Butterworth bandpass filtering with detrending
- Signal detrending & normalization
- Windowed FFT & Power Spectral Density (PSD)
- Heart Rate (BPM) extraction
- Signal-to-Noise Ratio (SNR) in decibels
"""

import numpy as np
from scipy import signal as sp_signal
from typing import Tuple

def detrend_signal(sig: np.ndarray) -> np.ndarray:
    """Remove slow baseline drift and DC offset."""
    if len(sig) < 4:
        return sig
    return sp_signal.detrend(sig, type='linear')

def butterworth_bandpass(
    sig: np.ndarray,
    lowcut: float = 0.75,   # 45 BPM
    highcut: float = 2.5,   # 150 BPM
    fs: float = 30.0,
    order: int = 2
) -> np.ndarray:
    """
    Apply zero-phase Butterworth bandpass filter.
    Applies detrending first to eliminate edge bounce and baseline drift.
    """
    if len(sig) < 15:
        return sig

    # Detrend first
    clean_sig = detrend_signal(sig)

    nyquist = 0.5 * fs
    low = max(0.01, lowcut / nyquist)
    high = min(0.99, highcut / nyquist)

    if low >= high:
        return clean_sig

    b, a = sp_signal.butter(order, [low, high], btype='bandpass')
    padlen = min(len(clean_sig) - 1, 3 * max(len(a), len(b)))
    
    try:
        filtered = sp_signal.filtfilt(b, a, clean_sig, padlen=padlen)
        return filtered
    except Exception:
        return clean_sig

def compute_psd(sig: np.ndarray, fs: float = 30.0, nfft: int = 1024) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute single-sided Power Spectral Density using windowed FFT.
    Returns: (frequencies in Hz, power spectral density)
    """
    N = len(sig)
    if N < 10:
        return np.array([0.0]), np.array([0.0])

    # Detrend and apply Hanning window to mitigate edge leakage
    sig_clean = detrend_signal(sig)
    window = np.hanning(N)
    windowed_sig = sig_clean * window

    # Zero-padded FFT for fine frequency resolution
    nfft = max(nfft, 2 ** int(np.ceil(np.log2(N))))
    fft_vals = np.fft.rfft(windowed_sig, n=nfft)
    freqs = np.fft.rfftfreq(nfft, d=1.0 / fs)

    psd = np.abs(fft_vals) ** 2
    return freqs, psd

def extract_bpm(freqs: np.ndarray, psd: np.ndarray, min_bpm: float = 45.0, max_bpm: float = 150.0) -> Tuple[float, float]:
    """
    Extract peak heart rate (BPM) within physiological limits.
    Returns: (estimated BPM, peak frequency in Hz)
    """
    min_freq = min_bpm / 60.0
    max_freq = max_bpm / 60.0

    valid_mask = (freqs >= min_freq) & (freqs <= max_freq)
    if not np.any(valid_mask):
        return 0.0, 0.0

    valid_freqs = freqs[valid_mask]
    valid_psd = psd[valid_mask]

    peak_idx = np.argmax(valid_psd)
    peak_freq = valid_freqs[peak_idx]
    bpm = peak_freq * 60.0

    return float(bpm), float(peak_freq)

def compute_snr(
    freqs: np.ndarray,
    psd: np.ndarray,
    peak_freq: float,
    half_bandwidth: float = 0.12,  # +/- ~7 BPM around peak
    min_freq: float = 0.75,
    max_freq: float = 2.5
) -> float:
    """
    Compute Signal-to-Noise Ratio (SNR) in decibels (dB).
    Measures spectral power concentration in the cardiac pulse peak & 1st harmonic
    relative to background noise across the physiological band.
    """
    if peak_freq <= 0:
        return -10.0

    band_mask = (freqs >= min_freq) & (freqs <= max_freq)
    if not np.any(band_mask):
        return -10.0

    # Fundamental peak mask
    fund_mask = (freqs >= peak_freq - half_bandwidth) & (freqs <= peak_freq + half_bandwidth)
    
    # First harmonic peak mask (2 * peak_freq)
    harm_freq = 2.0 * peak_freq
    harm_mask = (freqs >= harm_freq - half_bandwidth) & (freqs <= harm_freq + half_bandwidth) & band_mask

    signal_mask = (fund_mask | harm_mask) & band_mask
    noise_mask = band_mask & (~signal_mask)

    signal_power = np.sum(psd[signal_mask])
    noise_power = np.sum(psd[noise_mask])

    if noise_power <= 1e-9:
        return 15.0 if signal_power > 0 else -10.0

    snr_db = 10.0 * np.log10(signal_power / noise_power)
    return float(np.clip(snr_db, -15.0, 20.0))
